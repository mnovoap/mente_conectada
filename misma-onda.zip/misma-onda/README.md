# En la misma onda

Juego por parejas para celular: la app tira un dado (intentos), muestra una palabra de inicio y los dos jugadores intentan decir la misma palabra al mismo tiempo. Gana la primera pareja en llegar a 10 puntos.

Archivos: `index.html` (toda la app), `manifest.webmanifest`, `sw.js` (modo sin internet; sube la versión `onda-v1` → `onda-v2` cuando cambies algo) e `icons/`.
