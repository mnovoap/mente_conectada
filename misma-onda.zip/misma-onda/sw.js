/* Service worker: permite que la app funcione sin internet.
   IMPORTANTE: cada vez que cambies algún archivo, sube el número de versión
   (onda-v1 → onda-v2) para que los celulares descarguen la versión nueva. */
const PREFIX = 'onda-';
const CACHE = PREFIX + 'v1';
const ASSETS = ['./', './index.html', './manifest.webmanifest',
  './icons/icon-192.png', './icons/icon-512.png', './icons/icon-maskable-512.png', './icons/apple-touch-icon.png'];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)));
  self.skipWaiting();
});
// Solo borra versiones viejas de ESTA app (no toca las de Tabú, que vive en el mismo dominio)
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k.startsWith(PREFIX) && k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  if (!new URL(req.url).pathname.startsWith(new URL(self.registration.scope).pathname)) return;
  if (req.mode === 'navigate'){
    event.respondWith(fetch(req)
      .then(res => { const copy = res.clone(); caches.open(CACHE).then(c => c.put('./index.html', copy)); return res; })
      .catch(() => caches.match('./index.html')));
    return;
  }
  event.respondWith(caches.open(CACHE).then(c => c.match(req)).then(hit => hit || fetch(req)));
});
